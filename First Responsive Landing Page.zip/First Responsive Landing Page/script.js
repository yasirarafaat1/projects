// // Initialize Lenis
// const lenis = new Lenis();

// // Use requestAnimationFrame to continuously update the scroll
// function raf(time) {
//   lenis.raf(time);
//   requestAnimationFrame(raf);
// }

// requestAnimationFrame(raf);
// const i = document.querySelector(".i")
// const list = document.querySelector("#list");
// i.addEventListener("click", ()=>{
//     list.style.display = "block"
//     // i.style.display = "none"
// })
var loader = document.querySelector("#loader");

setTimeout(()=>{
    loader.style.top = "-100%";
}, 4000);